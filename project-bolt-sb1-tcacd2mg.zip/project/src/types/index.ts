export interface EmailResult {
  email: string;
  context: string;
  position: number;
  personName?: string;
  designation?: string;
  department?: string;
}

export interface ScrapeResult {
  url: string;
  emails: EmailResult[];
  totalFound: number;
  scrapedAt: string;
  error?: string;
}

export interface ScrapeStatus {
  isLoading: boolean;
  error: string | null;
  success: boolean;
}

export interface Contact {
  id: string;
  email: string;
  personName: string;
  designation: string;
  department?: string;
  organization: string;
  organizationType: 'university' | 'company' | 'other';
  sourceUrl?: string;
  addedAt: string;
  notes?: string;
}

export interface Organization {
  id: string;
  name: string;
  type: 'university' | 'company' | 'other';
  website?: string;
  contactCount: number;
  createdAt: string;
}