import React from 'react';
import { Mail, Copy, CheckCircle, Calendar, ExternalLink, User, Briefcase, Building, Plus } from 'lucide-react';
import { ScrapeResult, Contact } from '../types';
import { DatabaseManager } from '../utils/database';

interface EmailResultsProps {
  result: ScrapeResult | null;
}

export const EmailResults: React.FC<EmailResultsProps> = ({ result }) => {
  const [copiedEmails, setCopiedEmails] = React.useState<Set<string>>(new Set());
  const [showSaveModal, setShowSaveModal] = React.useState(false);
  const [selectedEmail, setSelectedEmail] = React.useState<any>(null);
  const [saveForm, setSaveForm] = React.useState({
    personName: '',
    designation: '',
    department: '',
    organization: '',
    organizationType: 'university' as 'university' | 'company' | 'other',
    notes: '',
  });

  if (!result) return null;

  const copyEmail = async (email: string) => {
    try {
      await navigator.clipboard.writeText(email);
      setCopiedEmails(prev => new Set(prev).add(email));
      setTimeout(() => {
        setCopiedEmails(prev => {
          const newSet = new Set(prev);
          newSet.delete(email);
          return newSet;
        });
      }, 2000);
    } catch (error) {
      console.error('Failed to copy email:', error);
    }
  };

  const copyAllEmails = async () => {
    const emailList = result.emails.map(e => e.email).join('\n');
    try {
      await navigator.clipboard.writeText(emailList);
      result.emails.forEach(e => {
        setCopiedEmails(prev => new Set(prev).add(e.email));
      });
      setTimeout(() => {
        setCopiedEmails(new Set());
      }, 2000);
    } catch (error) {
      console.error('Failed to copy emails:', error);
    }
  };

  const openSaveModal = (emailResult: any) => {
    setSelectedEmail(emailResult);
    setSaveForm({
      personName: emailResult.personName || '',
      designation: emailResult.designation || '',
      department: emailResult.department || '',
      organization: '',
      organizationType: 'university',
      notes: '',
    });
    setShowSaveModal(true);
  };

  const saveToDatabase = () => {
    if (!selectedEmail || !saveForm.organization.trim()) return;

    // Save organization first
    DatabaseManager.saveOrganization({
      name: saveForm.organization,
      type: saveForm.organizationType,
      website: result?.url,
    });

    // Save contact
    const contact: Omit<Contact, 'id' | 'addedAt'> = {
      email: selectedEmail.email,
      personName: saveForm.personName || 'Unknown',
      designation: saveForm.designation || 'Unknown',
      department: saveForm.department,
      organization: saveForm.organization,
      organizationType: saveForm.organizationType,
      sourceUrl: result?.url,
      notes: saveForm.notes,
    };

    DatabaseManager.saveContact(contact);
    setShowSaveModal(false);
    setSelectedEmail(null);
  };

  return (
    <>
      <div className="bg-gray-800 rounded-xl shadow-2xl p-8 border border-gray-700 card-hover">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-600 rounded-lg glow-button-green">
              <Mail className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">
                {result.totalFound} Email{result.totalFound !== 1 ? 's' : ''} Found
              </h2>
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <Calendar className="w-4 h-4 text-gray-500" />
                {new Date(result.scrapedAt).toLocaleString()}
              </div>
            </div>
          </div>
          
          {result.totalFound > 0 && (
            <button
              onClick={copyAllEmails}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all duration-300 flex items-center gap-2 glow-button transform hover:scale-105"
            >
              <Copy className="w-4 h-4" />
              Copy All
            </button>
          )}
        </div>

        <div className="mb-4 p-4 bg-gray-700/50 rounded-lg border border-gray-600">
          <div className="flex items-center gap-2 text-sm text-gray-300">
            <ExternalLink className="w-4 h-4 text-gray-400" />
            <span className="font-medium text-gray-200">Source:</span>
            <a 
              href={result.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300 truncate transition-colors"
            >
              {result.url}
            </a>
          </div>
        </div>

        {result.error ? (
          <div className="text-center py-8">
            <div className="text-red-400 mb-2">
              <Mail className="w-12 h-12 mx-auto opacity-50" />
            </div>
            <p className="text-red-400 font-medium">Error occurred while scraping</p>
            <p className="text-red-300 text-sm mt-1">{result.error}</p>
          </div>
        ) : result.totalFound === 0 ? (
          <div className="text-center py-8">
            <div className="text-gray-500 mb-2">
              <Mail className="w-12 h-12 mx-auto" />
            </div>
            <p className="text-gray-400 font-medium">No emails found</p>
            <p className="text-gray-500 text-sm mt-1">
              The website might not contain visible email addresses or they might be protected
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {result.emails.map((emailResult, index) => (
              <div
                key={index}
                className="border border-gray-600 rounded-lg p-6 hover:border-gray-500 transition-all duration-300 bg-gray-700/30 card-hover"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-gray-400" />
                    <span className="font-mono text-blue-400 font-medium">
                      {emailResult.email}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => openSaveModal(emailResult)}
                      className="p-2 hover:bg-green-600/20 rounded-lg transition-all duration-300 text-green-400 glow-button-green"
                      title="Save to database"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => copyEmail(emailResult.email)}
                      className="p-2 hover:bg-gray-600 rounded-lg transition-all duration-300 text-gray-400"
                      title="Copy email"
                    >
                      {copiedEmails.has(emailResult.email) ? (
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      ) : (
                        <Copy className="w-4 h-4 text-gray-400" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Person Details */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  {emailResult.personName && (
                    <div className="flex items-center gap-2 text-sm">
                      <User className="w-4 h-4 text-blue-400" />
                      <span className="font-medium text-gray-300">Name:</span>
                      <span className="text-white">{emailResult.personName}</span>
                    </div>
                  )}
                  
                  {emailResult.designation && (
                    <div className="flex items-center gap-2 text-sm">
                      <Briefcase className="w-4 h-4 text-purple-400" />
                      <span className="font-medium text-gray-300">Role:</span>
                      <span className="text-white">{emailResult.designation}</span>
                    </div>
                  )}
                  
                  {emailResult.department && (
                    <div className="flex items-center gap-2 text-sm">
                      <Building className="w-4 h-4 text-orange-400" />
                      <span className="font-medium text-gray-300">Department:</span>
                      <span className="text-white">{emailResult.department}</span>
                    </div>
                  )}
                </div>
                
                {emailResult.context && (
                  <div className="text-sm text-gray-300 bg-gray-800/50 p-3 rounded border-l-4 border-blue-500">
                    <span className="font-medium text-gray-200">Context: </span>
                    {emailResult.context}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Save Modal */}
      {showSaveModal && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl p-6 w-full max-w-md border border-gray-600 shadow-2xl">
            <h3 className="text-lg font-bold mb-4 text-white">Save Contact to Database</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={selectedEmail?.email || ''}
                  disabled
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg bg-gray-700 text-gray-300"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Person Name
                </label>
                <input
                  type="text"
                  value={saveForm.personName}
                  onChange={(e) => setSaveForm(prev => ({ ...prev, personName: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
                  placeholder="Enter person's name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Designation
                </label>
                <input
                  type="text"
                  value={saveForm.designation}
                  onChange={(e) => setSaveForm(prev => ({ ...prev, designation: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
                  placeholder="e.g., Professor, Manager, Director"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Department
                </label>
                <input
                  type="text"
                  value={saveForm.department}
                  onChange={(e) => setSaveForm(prev => ({ ...prev, department: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
                  placeholder="e.g., Computer Science, Marketing"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Organization *
                </label>
                <input
                  type="text"
                  value={saveForm.organization}
                  onChange={(e) => setSaveForm(prev => ({ ...prev, organization: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
                  placeholder="e.g., Harvard University, Google Inc."
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Organization Type
                </label>
                <select
                  value={saveForm.organizationType}
                  onChange={(e) => setSaveForm(prev => ({ ...prev, organizationType: e.target.value as any }))}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-700 text-white input-glow"
                >
                  <option value="university">University</option>
                  <option value="company">Company</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Notes
                </label>
                <textarea
                  value={saveForm.notes}
                  onChange={(e) => setSaveForm(prev => ({ ...prev, notes: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
                  rows={3}
                  placeholder="Additional notes..."
                />
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowSaveModal(false)}
                className="flex-1 px-4 py-2 border border-gray-600 rounded-lg hover:bg-gray-700 transition-all duration-300 text-gray-300 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={saveToDatabase}
                disabled={!saveForm.organization.trim()}
                className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition-all duration-300 glow-button"
              >
                Save Contact
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};