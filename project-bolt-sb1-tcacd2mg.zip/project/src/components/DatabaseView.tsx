import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Building, 
  Users, 
  Search, 
  Filter, 
  Download, 
  Upload, 
  Trash2, 
  Edit3,
  Mail,
  User,
  Briefcase,
  Calendar,
  Plus,
  X
} from 'lucide-react';
import { Contact, Organization } from '../types';
import { DatabaseManager } from '../utils/database';
import { FileImporter } from '../utils/fileImporter';

export const DatabaseView: React.FC = () => {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOrg, setSelectedOrg] = useState<string>('');
  const [selectedType, setSelectedType] = useState<string>('');
  const [showAddOrg, setShowAddOrg] = useState(false);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);
  
  const [newOrg, setNewOrg] = useState({
    name: '',
    type: 'university' as 'university' | 'company' | 'other',
    website: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setContacts(DatabaseManager.getContacts());
    setOrganizations(DatabaseManager.getOrganizations());
  };

  const filteredContacts = contacts.filter(contact => {
    const matchesSearch = 
      contact.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.personName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.designation.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.organization.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesOrg = !selectedOrg || contact.organization === selectedOrg;
    const matchesType = !selectedType || contact.organizationType === selectedType;
    
    return matchesSearch && matchesOrg && matchesType;
  });

  const handleDeleteContact = (id: string) => {
    if (confirm('Are you sure you want to delete this contact?')) {
      DatabaseManager.deleteContact(id);
      loadData();
    }
  };

  const handleDeleteOrganization = (id: string) => {
    if (confirm('Are you sure you want to delete this organization and all its contacts?')) {
      DatabaseManager.deleteOrganization(id);
      loadData();
    }
  };

  const handleAddOrganization = () => {
    if (newOrg.name.trim()) {
      DatabaseManager.saveOrganization(newOrg);
      setNewOrg({ name: '', type: 'university', website: '' });
      setShowAddOrg(false);
      loadData();
    }
  };

  const handleUpdateContact = (contact: Contact) => {
    DatabaseManager.updateContact(contact.id, contact);
    setEditingContact(null);
    loadData();
  };

  const exportData = () => {
    const data = DatabaseManager.exportData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `email-database-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      FileImporter.importFile(file).then(result => {
        if (result.success) {
          loadData();
          alert(result.message);
        } else {
          alert(result.message);
        }
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900 p-4">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <div className="bg-gray-800 rounded-xl shadow-2xl p-6 mb-6 border border-gray-700 card-hover">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-600 rounded-lg glow-button-purple">
                <Database className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Contact Database</h1>
                <p className="text-gray-300">Manage your extracted contacts and organizations</p>
              </div>
            </div>
            
            <div className="flex gap-3">
              <label className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-all duration-300 flex items-center gap-2 cursor-pointer glow-button-green transform hover:scale-105">
                <Upload className="w-4 h-4" />
                Import
                <input
                  type="file"
                  accept=".json,.xlsx,.xls,.docx,.csv"
                  onChange={importData}
                  className="hidden"
                />
              </label>
              <button
                onClick={exportData}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all duration-300 flex items-center gap-2 glow-button transform hover:scale-105"
              >
                <Download className="w-4 h-4" />
                Export
              </button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-gray-800 rounded-xl shadow-2xl p-6 border border-gray-700 card-hover">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-600 rounded-lg glow-button">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">Total Contacts</h3>
                <p className="text-2xl font-bold text-blue-600">{contacts.length}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-800 rounded-xl shadow-2xl p-6 border border-gray-700 card-hover">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-green-600 rounded-lg glow-button-green">
                <Building className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">Organizations</h3>
                <p className="text-2xl font-bold text-green-600">{organizations.length}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-800 rounded-xl shadow-2xl p-6 border border-gray-700 card-hover">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-600 rounded-lg glow-button-purple">
                <Database className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">Universities</h3>
                <p className="text-2xl font-bold text-purple-600">
                  {organizations.filter(org => org.type === 'university').length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Organizations Management */}
        <div className="bg-gray-800 rounded-xl shadow-2xl p-6 mb-6 border border-gray-700 card-hover">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-white">Organizations</h2>
            <button
              onClick={() => setShowAddOrg(true)}
              className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition-all duration-300 flex items-center gap-2 glow-button-purple transform hover:scale-105"
            >
              <Plus className="w-4 h-4" />
              Add Organization
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {organizations.map(org => (
              <div key={org.id} className="border border-gray-600 rounded-lg p-4 hover:border-gray-500 transition-all duration-300 bg-gray-700/30 card-hover">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-white">{org.name}</h3>
                  <button
                    onClick={() => handleDeleteOrganization(org.id)}
                    className="text-red-400 hover:text-red-300 p-1 hover:bg-red-600/20 rounded transition-all duration-300 glow-button-red"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="text-sm text-gray-300 space-y-1">
                  <p className="capitalize">{org.type}</p>
                  <p>{org.contactCount} contacts</p>
                  {org.website && (
                    <a href={org.website} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300 transition-colors">
                      Visit Website
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Filters */}
        <div className="bg-gray-800 rounded-xl shadow-2xl p-6 mb-6 border border-gray-700 card-hover">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="text"
                placeholder="Search contacts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
              />
            </div>
            
            <select
              value={selectedOrg}
              onChange={(e) => setSelectedOrg(e.target.value)}
              className="px-4 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-gray-700 text-white input-glow"
            >
              <option value="">All Organizations</option>
              {organizations.map(org => (
                <option key={org.id} value={org.name}>{org.name}</option>
              ))}
            </select>
            
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="px-4 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-gray-700 text-white input-glow"
            >
              <option value="">All Types</option>
              <option value="university">University</option>
              <option value="company">Company</option>
              <option value="other">Other</option>
            </select>
            
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <Filter className="w-4 h-4 text-gray-500" />
              {filteredContacts.length} of {contacts.length} contacts
            </div>
          </div>
        </div>

        {/* Contacts List */}
        <div className="bg-gray-800 rounded-xl shadow-2xl p-6 border border-gray-700 card-hover">
          <h2 className="text-xl font-bold text-white mb-6">Contacts</h2>
          
          {filteredContacts.length === 0 ? (
            <div className="text-center py-8">
              <Users className="w-12 h-12 mx-auto text-gray-500 mb-2" />
              <p className="text-gray-400">No contacts found</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredContacts.map(contact => (
                <div key={contact.id} className="border border-gray-600 rounded-lg p-6 hover:border-gray-500 transition-all duration-300 bg-gray-700/30 card-hover">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-600 rounded-lg glow-button">
                        <User className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">{contact.personName}</h3>
                        <p className="text-sm text-gray-400">{contact.organization}</p>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <button
                        onClick={() => setEditingContact(contact)}
                        className="p-2 hover:bg-gray-600 rounded-lg transition-all duration-300 text-gray-400 hover:text-white"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteContact(contact.id)}
                        className="p-2 hover:bg-red-600/20 rounded-lg transition-all duration-300 text-red-400 hover:text-red-300 glow-button-red"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-blue-400" />
                      <span className="font-mono text-gray-300">{contact.email}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-purple-400" />
                      <span className="text-gray-300">{contact.designation}</span>
                    </div>
                    
                    {contact.department && (
                      <div className="flex items-center gap-2">
                        <Building className="w-4 h-4 text-orange-400" />
                        <span className="text-gray-300">{contact.department}</span>
                      </div>
                    )}
                    
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-green-400" />
                      <span className="text-gray-300">{new Date(contact.addedAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  
                  {contact.notes && (
                    <div className="mt-3 p-3 bg-gray-800/50 rounded-lg border border-gray-600">
                      <p className="text-sm text-gray-300">{contact.notes}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Add Organization Modal */}
      {showAddOrg && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl p-6 w-full max-w-md border border-gray-600 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white">Add Organization</h3>
              <button
                onClick={() => setShowAddOrg(false)}
                className="p-2 hover:bg-gray-700 rounded-lg text-gray-400 hover:text-white transition-all duration-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Organization Name *
                </label>
                <input
                  type="text"
                  value={newOrg.name}
                  onChange={(e) => setNewOrg(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
                  placeholder="e.g., Harvard University"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Type
                </label>
                <select
                  value={newOrg.type}
                  onChange={(e) => setNewOrg(prev => ({ ...prev, type: e.target.value as any }))}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-gray-700 text-white input-glow"
                >
                  <option value="university">University</option>
                  <option value="company">Company</option>
                  <option value="other">Other</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Website
                </label>
                <input
                  type="url"
                  value={newOrg.website}
                  onChange={(e) => setNewOrg(prev => ({ ...prev, website: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
                  placeholder="https://example.com"
                />
              </div>
            </div>
            
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowAddOrg(false)}
                className="flex-1 px-4 py-2 border border-gray-600 rounded-lg hover:bg-gray-700 transition-all duration-300 text-gray-300 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleAddOrganization}
                disabled={!newOrg.name.trim()}
                className="flex-1 px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition-all duration-300 glow-button-purple"
              >
                Add Organization
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Contact Modal */}
      {editingContact && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl p-6 w-full max-w-md border border-gray-600 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white">Edit Contact</h3>
              <button
                onClick={() => setEditingContact(null)}
                className="p-2 hover:bg-gray-700 rounded-lg text-gray-400 hover:text-white transition-all duration-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Person Name
                </label>
                <input
                  type="text"
                  value={editingContact.personName}
                  onChange={(e) => setEditingContact(prev => prev ? { ...prev, personName: e.target.value } : null)}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={editingContact.email}
                  onChange={(e) => setEditingContact(prev => prev ? { ...prev, email: e.target.value } : null)}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Designation
                </label>
                <input
                  type="text"
                  value={editingContact.designation}
                  onChange={(e) => setEditingContact(prev => prev ? { ...prev, designation: e.target.value } : null)}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Department
                </label>
                <input
                  type="text"
                  value={editingContact.department || ''}
                  onChange={(e) => setEditingContact(prev => prev ? { ...prev, department: e.target.value } : null)}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Notes
                </label>
                <textarea
                  value={editingContact.notes || ''}
                  onChange={(e) => setEditingContact(prev => prev ? { ...prev, notes: e.target.value } : null)}
                  className="w-full px-3 py-2 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-gray-700 text-white placeholder-gray-400 input-glow"
                  rows={3}
                />
              </div>
            </div>
            
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setEditingContact(null)}
                className="flex-1 px-4 py-2 border border-gray-600 rounded-lg hover:bg-gray-700 transition-all duration-300 text-gray-300 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={() => handleUpdateContact(editingContact)}
                className="flex-1 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-all duration-300 glow-button-purple"
              >
                Update Contact
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};