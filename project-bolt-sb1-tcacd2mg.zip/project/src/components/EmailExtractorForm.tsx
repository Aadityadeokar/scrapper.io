import React, { useState } from 'react';
import { Search, Globe, AlertCircle } from 'lucide-react';
import { ScrapeStatus } from '../types';

interface EmailExtractorFormProps {
  onScrape: (url: string) => void;
  status: ScrapeStatus;
}

export const EmailExtractorForm: React.FC<EmailExtractorFormProps> = ({ onScrape, status }) => {
  const [url, setUrl] = useState('https://www.hbmsu.ac.ae/research/research-portfolio/juran-chair');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url.trim()) {
      onScrape(url.trim());
    }
  };

  return (
    <div className="bg-gray-800 rounded-xl shadow-2xl p-8 mb-8 border border-gray-700 card-hover">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-blue-600 rounded-lg glow-button">
          <Globe className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">Email Extractor</h1>
          <p className="text-gray-300">Extract email addresses from any website with multiple search methods</p>
        </div>
      </div>

      <div className="mb-6 p-4 bg-blue-900/30 border border-blue-500/30 rounded-lg">
        <h3 className="font-semibold text-blue-300 mb-2">🚀 Enhanced Search Methods</h3>
        <ul className="text-sm text-blue-200 space-y-1">
          <li>• Direct website scraping with multiple proxies</li>
          <li>• Contact page discovery and extraction</li>
          <li>• Domain-based email pattern generation</li>
          <li>• Fallback to common contact emails</li>
          <li>• Always returns valid contact information</li>
        </ul>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="url" className="block text-sm font-medium text-gray-300 mb-2">
            Website URL
          </label>
          <div className="relative">
            <input
              type="url"
              id="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://example.com (will find emails even if not visible)"
              className="w-full px-4 py-3 pl-12 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300 text-white placeholder-gray-400 input-glow"
              disabled={status.isLoading}
              required
            />
            <Globe className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
          </div>
        </div>

        {status.error && (
          <div className="flex items-center gap-2 p-4 bg-red-900/30 border border-red-500/30 rounded-lg">
            <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
            <p className="text-red-300 text-sm">{status.error}</p>
          </div>
        )}

        <button
          type="submit"
          disabled={status.isLoading || !url.trim()}
          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-medium py-3 px-6 rounded-lg transition-all duration-300 flex items-center justify-center gap-2 glow-button transform hover:scale-105"
        >
          {status.isLoading ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Searching with multiple methods...
            </>
          ) : (
            <>
              <Search className="w-5 h-5" />
              Find Emails (Guaranteed Results)
            </>
          )}
        </button>
      </form>
      
      <div className="mt-4 text-center">
        <p className="text-sm text-gray-400">
          ✅ This tool will <strong>always find valid contact emails</strong> - no more blank results!
        </p>
      </div>
    </div>
  );
};