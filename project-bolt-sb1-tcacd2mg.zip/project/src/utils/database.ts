import { Contact, Organization } from '../types';

export class DatabaseManager {
  private static readonly CONTACTS_KEY = 'email_extractor_contacts';
  private static readonly ORGANIZATIONS_KEY = 'email_extractor_organizations';

  static saveContact(contact: Omit<Contact, 'id' | 'addedAt'>): Contact {
    const contacts = this.getContacts();
    const newContact: Contact = {
      ...contact,
      id: this.generateId(),
      addedAt: new Date().toISOString(),
    };

    contacts.push(newContact);
    localStorage.setItem(this.CONTACTS_KEY, JSON.stringify(contacts));

    // Update organization contact count
    this.updateOrganizationContactCount(contact.organization);

    return newContact;
  }

  static getContacts(): Contact[] {
    const stored = localStorage.getItem(this.CONTACTS_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  static getContactsByOrganization(organizationName: string): Contact[] {
    return this.getContacts().filter(contact => 
      contact.organization.toLowerCase() === organizationName.toLowerCase()
    );
  }

  static updateContact(id: string, updates: Partial<Contact>): boolean {
    const contacts = this.getContacts();
    const index = contacts.findIndex(contact => contact.id === id);
    
    if (index === -1) return false;

    contacts[index] = { ...contacts[index], ...updates };
    localStorage.setItem(this.CONTACTS_KEY, JSON.stringify(contacts));
    return true;
  }

  static deleteContact(id: string): boolean {
    const contacts = this.getContacts();
    const contact = contacts.find(c => c.id === id);
    
    if (!contact) return false;

    const filtered = contacts.filter(contact => contact.id !== id);
    localStorage.setItem(this.CONTACTS_KEY, JSON.stringify(filtered));

    // Update organization contact count
    this.updateOrganizationContactCount(contact.organization);
    return true;
  }

  static saveOrganization(org: Omit<Organization, 'id' | 'createdAt' | 'contactCount'>): Organization {
    const organizations = this.getOrganizations();
    const existing = organizations.find(o => o.name.toLowerCase() === org.name.toLowerCase());
    
    if (existing) return existing;

    const newOrg: Organization = {
      ...org,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
      contactCount: 0,
    };

    organizations.push(newOrg);
    localStorage.setItem(this.ORGANIZATIONS_KEY, JSON.stringify(organizations));
    return newOrg;
  }

  static getOrganizations(): Organization[] {
    const stored = localStorage.getItem(this.ORGANIZATIONS_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  static updateOrganization(id: string, updates: Partial<Organization>): boolean {
    const organizations = this.getOrganizations();
    const index = organizations.findIndex(org => org.id === id);
    
    if (index === -1) return false;

    organizations[index] = { ...organizations[index], ...updates };
    localStorage.setItem(this.ORGANIZATIONS_KEY, JSON.stringify(organizations));
    return true;
  }

  static deleteOrganization(id: string): boolean {
    const organizations = this.getOrganizations();
    const filtered = organizations.filter(org => org.id !== id);
    localStorage.setItem(this.ORGANIZATIONS_KEY, JSON.stringify(filtered));
    
    // Also delete all contacts from this organization
    const contacts = this.getContacts();
    const org = organizations.find(o => o.id === id);
    if (org) {
      const filteredContacts = contacts.filter(contact => 
        contact.organization.toLowerCase() !== org.name.toLowerCase()
      );
      localStorage.setItem(this.CONTACTS_KEY, JSON.stringify(filteredContacts));
    }
    
    return true;
  }

  private static updateOrganizationContactCount(organizationName: string): void {
    const organizations = this.getOrganizations();
    const contacts = this.getContacts();
    
    const org = organizations.find(o => 
      o.name.toLowerCase() === organizationName.toLowerCase()
    );
    
    if (org) {
      const contactCount = contacts.filter(c => 
        c.organization.toLowerCase() === organizationName.toLowerCase()
      ).length;
      
      this.updateOrganization(org.id, { contactCount });
    }
  }

  private static generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  static exportData(): string {
    const data = {
      contacts: this.getContacts(),
      organizations: this.getOrganizations(),
      exportedAt: new Date().toISOString(),
    };
    return JSON.stringify(data, null, 2);
  }

  static importData(jsonData: string): boolean {
    try {
      const data = JSON.parse(jsonData);
      if (data.contacts) {
        localStorage.setItem(this.CONTACTS_KEY, JSON.stringify(data.contacts));
      }
      if (data.organizations) {
        localStorage.setItem(this.ORGANIZATIONS_KEY, JSON.stringify(data.organizations));
      }
      return true;
    } catch {
      return false;
    }
  }
}