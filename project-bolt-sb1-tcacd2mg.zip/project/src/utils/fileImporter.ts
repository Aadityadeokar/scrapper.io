import * as XLSX from 'xlsx';
import { Document, Packer, Paragraph, TextRun } from 'docx';
import { Contact, Organization } from '../types';
import { DatabaseManager } from './database';

export class FileImporter {
  static async importFile(file: File): Promise<{ success: boolean; message: string; contacts?: Contact[] }> {
    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    
    try {
      switch (fileExtension) {
        case 'json':
          return await this.importJSON(file);
        case 'xlsx':
        case 'xls':
          return await this.importExcel(file);
        case 'docx':
          return await this.importWord(file);
        case 'csv':
          return await this.importCSV(file);
        default:
          return { success: false, message: 'Unsupported file format. Please use JSON, Excel (.xlsx/.xls), Word (.docx), or CSV files.' };
      }
    } catch (error) {
      return { success: false, message: `Error importing file: ${error instanceof Error ? error.message : 'Unknown error'}` };
    }
  }

  private static async importJSON(file: File): Promise<{ success: boolean; message: string; contacts?: Contact[] }> {
    const content = await file.text();
    if (DatabaseManager.importData(content)) {
      return { success: true, message: 'JSON data imported successfully!' };
    } else {
      return { success: false, message: 'Failed to import JSON data. Please check the file format.' };
    }
  }

  private static async importExcel(file: File): Promise<{ success: boolean; message: string; contacts?: Contact[] }> {
    const arrayBuffer = await file.arrayBuffer();
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet);

    const contacts: Contact[] = [];
    const organizations = new Set<string>();

    for (const row of data as any[]) {
      // Try to map common column names
      const email = row.email || row.Email || row.EMAIL || row['Email Address'] || '';
      const personName = row.name || row.Name || row.NAME || row['Person Name'] || row['Full Name'] || '';
      const designation = row.designation || row.Designation || row.Title || row.Position || row.Role || '';
      const department = row.department || row.Department || row.Faculty || row.Division || '';
      const organization = row.organization || row.Organization || row.Company || row.University || row.Institution || '';
      const organizationType = row.organizationType || row['Organization Type'] || row.Type || 'other';
      const notes = row.notes || row.Notes || row.Comments || '';

      if (email && this.isValidEmail(email)) {
        // Save organization
        if (organization) {
          organizations.add(organization);
          DatabaseManager.saveOrganization({
            name: organization,
            type: organizationType as 'university' | 'company' | 'other',
          });
        }

        // Save contact
        const contact = DatabaseManager.saveContact({
          email: email.toLowerCase(),
          personName: personName || 'Unknown',
          designation: designation || 'Unknown',
          department: department || '',
          organization: organization || 'Unknown Organization',
          organizationType: organizationType as 'university' | 'company' | 'other' || 'other',
          notes: notes || '',
        });

        contacts.push(contact);
      }
    }

    return {
      success: true,
      message: `Successfully imported ${contacts.length} contacts from ${organizations.size} organizations.`,
      contacts
    };
  }

  private static async importWord(file: File): Promise<{ success: boolean; message: string; contacts?: Contact[] }> {
    const arrayBuffer = await file.arrayBuffer();
    
    // For Word documents, we'll extract text and look for email patterns
    // This is a simplified approach - in production, you'd use a proper Word parser
    const uint8Array = new Uint8Array(arrayBuffer);
    const text = new TextDecoder().decode(uint8Array);
    
    const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
    const emails = text.match(emailRegex) || [];
    
    const contacts: Contact[] = [];
    const seenEmails = new Set<string>();

    for (const email of emails) {
      if (!seenEmails.has(email.toLowerCase()) && this.isValidEmail(email)) {
        seenEmails.add(email.toLowerCase());
        
        const contact = DatabaseManager.saveContact({
          email: email.toLowerCase(),
          personName: 'Unknown',
          designation: 'Unknown',
          department: '',
          organization: 'Imported from Word Document',
          organizationType: 'other',
          notes: 'Imported from Word document',
        });

        contacts.push(contact);
      }
    }

    return {
      success: true,
      message: `Successfully extracted ${contacts.length} unique emails from Word document.`,
      contacts
    };
  }

  private static async importCSV(file: File): Promise<{ success: boolean; message: string; contacts?: Contact[] }> {
    const content = await file.text();
    const lines = content.split('\n');
    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    
    const contacts: Contact[] = [];
    const organizations = new Set<string>();

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
      const row: any = {};
      
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });

      const email = row.email || row.Email || row.EMAIL || row['Email Address'] || '';
      const personName = row.name || row.Name || row.NAME || row['Person Name'] || row['Full Name'] || '';
      const designation = row.designation || row.Designation || row.Title || row.Position || row.Role || '';
      const department = row.department || row.Department || row.Faculty || row.Division || '';
      const organization = row.organization || row.Organization || row.Company || row.University || row.Institution || '';
      const organizationType = row.organizationType || row['Organization Type'] || row.Type || 'other';
      const notes = row.notes || row.Notes || row.Comments || '';

      if (email && this.isValidEmail(email)) {
        // Save organization
        if (organization) {
          organizations.add(organization);
          DatabaseManager.saveOrganization({
            name: organization,
            type: organizationType as 'university' | 'company' | 'other',
          });
        }

        // Save contact
        const contact = DatabaseManager.saveContact({
          email: email.toLowerCase(),
          personName: personName || 'Unknown',
          designation: designation || 'Unknown',
          department: department || '',
          organization: organization || 'Unknown Organization',
          organizationType: organizationType as 'university' | 'company' | 'other' || 'other',
          notes: notes || '',
        });

        contacts.push(contact);
      }
    }

    return {
      success: true,
      message: `Successfully imported ${contacts.length} contacts from ${organizations.size} organizations.`,
      contacts
    };
  }

  private static isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email) && !email.includes('example') && !email.includes('test@test');
  }

  static async exportToExcel(contacts: Contact[], organizations: Organization[]): Promise<void> {
    const contactsData = contacts.map(contact => ({
      'Email': contact.email,
      'Person Name': contact.personName,
      'Designation': contact.designation,
      'Department': contact.department || '',
      'Organization': contact.organization,
      'Organization Type': contact.organizationType,
      'Source URL': contact.sourceUrl || '',
      'Notes': contact.notes || '',
      'Added Date': new Date(contact.addedAt).toLocaleDateString()
    }));

    const organizationsData = organizations.map(org => ({
      'Organization Name': org.name,
      'Type': org.type,
      'Website': org.website || '',
      'Contact Count': org.contactCount,
      'Created Date': new Date(org.createdAt).toLocaleDateString()
    }));

    const workbook = XLSX.utils.book_new();
    
    const contactsSheet = XLSX.utils.json_to_sheet(contactsData);
    const organizationsSheet = XLSX.utils.json_to_sheet(organizationsData);
    
    XLSX.utils.book_append_sheet(workbook, contactsSheet, 'Contacts');
    XLSX.utils.book_append_sheet(workbook, organizationsSheet, 'Organizations');
    
    XLSX.writeFile(workbook, `email-database-${new Date().toISOString().split('T')[0]}.xlsx`);
  }

  static async exportToWord(contacts: Contact[]): Promise<void> {
    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            children: [
              new TextRun({
                text: "Email Database Export",
                bold: true,
                size: 32,
              }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: `Generated on: ${new Date().toLocaleDateString()}`,
                italics: true,
              }),
            ],
          }),
          new Paragraph({ text: "" }),
          ...contacts.flatMap(contact => [
            new Paragraph({
              children: [
                new TextRun({
                  text: contact.personName,
                  bold: true,
                  size: 24,
                }),
              ],
            }),
            new Paragraph({
              children: [
                new TextRun({
                  text: `Email: ${contact.email}`,
                }),
              ],
            }),
            new Paragraph({
              children: [
                new TextRun({
                  text: `Designation: ${contact.designation}`,
                }),
              ],
            }),
            new Paragraph({
              children: [
                new TextRun({
                  text: `Organization: ${contact.organization}`,
                }),
              ],
            }),
            new Paragraph({ text: "" }),
          ])
        ],
      }],
    });

    const buffer = await Packer.toBuffer(doc);
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `email-database-${new Date().toISOString().split('T')[0]}.docx`;
    a.click();
    URL.revokeObjectURL(url);
  }
}