import React, { useState } from 'react';
import { EmailExtractorForm } from './components/EmailExtractorForm';
import { EmailResults } from './components/EmailResults';
import { DatabaseView } from './components/DatabaseView';
import { EmailExtractor } from './utils/emailExtractor';
import { ScrapeResult, ScrapeStatus } from './types';
import { Search, Database } from 'lucide-react';

function App() {
  const [currentView, setCurrentView] = useState<'extractor' | 'database'>('extractor');
  const [result, setResult] = React.useState<ScrapeResult | null>(null);
  const [status, setStatus] = React.useState<ScrapeStatus>({
    isLoading: false,
    error: null,
    success: false,
  });

  const handleScrape = async (url: string) => {
    setStatus({ isLoading: true, error: null, success: false });
    setResult(null);

    try {
      const scrapeResult = await EmailExtractor.scrapeEmails(url);
      
      if (scrapeResult.error) {
        setStatus({
          isLoading: false,
          error: scrapeResult.error,
          success: false,
        });
      } else {
        setStatus({
          isLoading: false,
          error: null,
          success: true,
        });
      }
      
      setResult(scrapeResult);
    } catch (error) {
      setStatus({
        isLoading: false,
        error: error instanceof Error ? error.message : 'An unexpected error occurred',
        success: false,
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Navigation */}
      <nav className="bg-gray-800 shadow-lg border-b border-gray-700">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-600 rounded-lg glow-button">
                <Search className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-xl font-bold text-white">Scrapper Sharma</h1>
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={() => setCurrentView('extractor')}
                className={`px-4 py-2 rounded-lg transition-all duration-300 flex items-center gap-2 glow-button ${
                  currentView === 'extractor'
                    ? 'bg-blue-600 text-white shadow-lg'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
              >
                <Search className="w-4 h-4" />
                Extractor
              </button>
              <button
                onClick={() => setCurrentView('database')}
                className={`px-4 py-2 rounded-lg transition-all duration-300 flex items-center gap-2 glow-button-purple ${
                  currentView === 'database'
                    ? 'bg-purple-600 text-white shadow-lg'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
              >
                <Database className="w-4 h-4" />
                DataStack
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      {currentView === 'extractor' ? (
        <div className="bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 min-h-screen">
          <div className="container mx-auto px-4 py-8 max-w-4xl">
            <EmailExtractorForm onScrape={handleScrape} status={status} />
            <EmailResults result={result} />
          </div>
        </div>
      ) : (
        <DatabaseView />
      )}
    </div>
  );
}

export default App;